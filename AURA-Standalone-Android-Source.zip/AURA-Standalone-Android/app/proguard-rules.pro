# No custom shrinking rules are needed for the first standalone release.
