# AURA Standalone Android

A standalone Android app project. It does **not** use Hatchable, a Hatchable URL, or Hatchable APIs.

## Included in v1

- Local-first AURA dashboard and chat UI
- On-device SQLite storage for memories, skills, approvals and chat history
- Teachable skill library and a four-skill coding starter pack
- Coding language catalog (HTML, CSS, JavaScript, TypeScript, Python, C/C++, C#, Java, Kotlin, Swift, Go, Rust, PHP, Ruby, Dart, Lua, SQL, Bash, PowerShell, GDScript and more)
- Configurable OpenAI-compatible HTTPS model endpoint
- Model API key encrypted with Android Keystore AES-GCM
- Chat sends saved memories and active skills as context to the model endpoint
- Approval queue for proposed actions

## Important limitations

- Memory and skills are stored on this device; there is no cloud sync in this version.
- The app does not bundle model weights or GPU hosting. Configure an HTTPS model endpoint you control in Settings.
- The cloud computer/terminal worker is not included yet. The approval list records decisions but does not execute shell commands.
- Language names in the Coding Lab are a catalog and prompt helper; compilers and SDKs are not bundled into the APK.
- This is a debug APK build workflow. A release APK would need a signing key you manage securely.

## Build locally

Requirements: JDK 17, Android SDK platform 35, Android build-tools 35.0.0, and Gradle 8.9.

```bash
gradle --no-daemon assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Build using GitHub Actions

1. Create a GitHub repository and upload the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab.
3. Run **Build AURA Android APK**, or push a commit to `main`.
4. Open the completed workflow run and download the `AURA-Standalone-debug-apk` artifact.
5. Extract `app-debug.apk` and install it on your Android device. Android may ask you to allow installation from the browser or file manager you used.

## Model endpoint format

The app expects an OpenAI-compatible chat-completions API. Enter the HTTPS base URL, such as `https://your-host.example/v1`, the exact model ID exposed by that server, and its API key in AURA Settings. The API key is encrypted on-device using Android Keystore. Do not put credentials in the source code or commit them to GitHub.

## Package

- Application ID: `com.aura.standalone`
- App name: `AURA AI`
- Minimum Android: API 26 (Android 8.0)
- Target Android: API 35
